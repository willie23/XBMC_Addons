define(['angular'], function (ng) {
    'use strict';
    return ng.module('ptvlKodi.ptvlControllers', ['ptvlKodi.kodiServices', 'ptvlKodi.televisionServices']);
});