define([
    './showList',
    './showDetails'
], function () {});