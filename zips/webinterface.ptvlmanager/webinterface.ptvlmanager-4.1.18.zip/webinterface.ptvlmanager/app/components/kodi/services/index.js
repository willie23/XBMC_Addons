define([
    './playlist'
], function () {});