define([
    './dialogs',
    './../min/services/settingsXml.min',
    './../min/services/plugins.min',
    './rules',
    './rssCommunity',
    './../min/services/lock.min'
], function () {});