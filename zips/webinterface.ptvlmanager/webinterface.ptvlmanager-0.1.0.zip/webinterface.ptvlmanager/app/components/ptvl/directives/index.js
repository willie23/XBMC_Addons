define([
    './../min/directives/onReadFile.min'
], function () {});