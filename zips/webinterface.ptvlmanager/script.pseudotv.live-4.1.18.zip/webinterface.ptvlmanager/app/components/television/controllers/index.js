define([
    './showList',
    './showDetails'
], function () {});