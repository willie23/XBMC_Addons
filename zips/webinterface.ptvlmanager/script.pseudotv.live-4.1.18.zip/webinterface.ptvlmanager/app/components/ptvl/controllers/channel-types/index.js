define([
    '../../min/controllers/channel-types/plugin.min',
    '../../min/controllers/channel-types/youtube.min',
    './playlist',
    './tvStudio'
], function () {});