define([
    './dialogs',
    './../min/services/settingsXml.min',
    './../min/services/plugins.min',
    './../min/services/rules.min',
    './../min/services/lock.min'
], function () {});