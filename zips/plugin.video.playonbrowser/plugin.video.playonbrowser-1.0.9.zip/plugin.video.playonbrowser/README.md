# plugin.video.playonbrowser
Provides a native interface to browsing m.playon.tv in your local network. 

### STRM 
One of the reasons I created this was so I can use MyLibrary with this addon so I do not have refresh every hour incase the process restarts or other scenarios cause the Ids to change. 
